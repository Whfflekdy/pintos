#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int
main (int argc, char **argv)
{
  if (argc != 5)
    {
      printf ("usage: additional [num 1] [num 2] [num 3] [num 4]\n");
      return EXIT_FAILURE;
    }

  int a = atoi (argv[1]);
  int b = atoi (argv[2]);
  int c = atoi (argv[3]);
  int d = atoi (argv[4]);

  printf ("%d %d\n", fibonacci (a), max_of_four_int (a, b, c, d));
  return EXIT_SUCCESS;
}