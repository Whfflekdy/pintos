#include "userprog/syscall.h"
#include "threads/vaddr.h"
#include <stdio.h>
#include "userprog/pagedir.h" // for pagedir_get_page()
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "threads/synch.h" // for struct lock
#include "filesys/off_t.h"
#include "devices/input.h" // for input_getc()
#include "filesys/file.h" // for file_read(), file_write()
#include "threads/palloc.h"     // for palloc_get_page, palloc_free_page
#include "userprog/process.h"   // for process_execute, process_wait
#include "lib/string.h"         // for strlcpy
#include "filesys/filesys.h"

static void syscall_handler (struct intr_frame *);
struct lock filesys_lock; // 커널 전체에서 공유할 수 있는 락 변수 선언

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
   // 시스템콜 서브 시스템이 처음 켜질 때 락을 딱 한 번 초기화
  lock_init(&filesys_lock);
}

// 전달받은 포인터가 유효한 유저 메모리 주소인지 확인하는 함수
void
check_addr(const void *vaddr){
  // 1. 널포인터인지
  // 2. 유저 가장 메모리 영역(PHYS_BASE 미만)이 맞는지
  // 3. 페이지 디렉토리에 실제로 매핑된 페이지가 존재하는지
  if(vaddr== NULL || !is_user_vaddr(vaddr) || pagedir_get_page(thread_current() -> pagedir, vaddr)== NULL)
    sys_exit(-1); // 유효하지 않으면 종료. 
  return;
}

// 문자열 전체가 유효한 유저 메모리인지 한 글자씩 검사
static void
check_str(const char *str)
{
  for(;;)
  {
    check_addr(str);
    if(*str == '\0')
      return;
    str++;
  }
}

// buffer부터 size 바이트가 전부 유효한지 검사(페이지마다 한 번씩)
static void
check_buffer(const void* buffer, unsigned size)
{
  const uint8_t *start = buffer;
  const uint8_t *end;
  const uint8_t *p;

  if(size == 0)
    return;
  end = start + size -1;
  if(end<start)
    sys_exit(-1);
  
  check_addr(start);
  check_addr(end);
  for(p = (const uint8_t *) pg_round_down(start)+PGSIZE; p<=end; p+=PGSIZE)
    check_addr(p);
}

// esp+4idx위치의 인자 하나를 검사후 꺼내는 함수(idx 0 = syscall num)
static uint32_t
get_arg(struct intr_frame *f, int idx)
{
  uint8_t *p = (uint8_t *)f->esp+4*idx;
  check_addr(p);
  check_addr(p+3); // 4바이트가 페이지 경계에 걸칠 수 있기 때문.
  return *(uint32_t *)p;
}

//fd->struct file* 범위 밖이거나 안 열린 fd면 NULL
static struct file*
fd_to_file(int fd)
{
  if(fd<2 || fd >= FD_MAX)
    return NULL;
  return thread_current() -> fd_table[fd];
}

static int
alloc_fd(struct file *file)
{
  struct thread *cur = thread_current();
  for(int fd = 2; fd <FD_MAX; fd++)
    if(cur->fd_table[fd]== NULL){
      cur->fd_table[fd] = file;
      return fd;
    }
  return -1;
}

void 
sys_halt(void){
  // shutdown_power_off()를 호출함으로써 pintos를 종료시킨다.
  // 가능한 한 드물게 사용해야한다. 
  // 발생 가능한 교착 상태(deadlock) 상황 등에 대한 일부 정보를 잃게 되기 때문이다. 
  shutdown_power_off();
  return;
}

void 
sys_exit(int exit_status){
  // void exit(int status)
  // 현재의 유저 프로그램을 종료하고 커널에 status를 반환한다.
  // 만일 process의 부모가 wait 상태로 이 프로그램의 종료를 기다리고 있다면-> 아래 wait()에서 이어서 설명. 
  // 관례적으로, 0의 상태가 성공을 가리키고, nonzero value는 에러를 가리킨다. 
  struct thread *curr = thread_current(); // 현재 실행 중인 스레드를 가져와서
  
  // 종료 상태를 현재 스레드 구조체에 저장.
  curr-> exit_status = exit_status;

  // "Process Name: exit(exit status)"를 출력.
  printf("%s: exit(%d)\n", curr->name, exit_status);
  thread_exit(); // 커널의 스레드 종료 함수 호출. 
}

tid_t 
sys_exec(const char *cmd_line){
  check_str(cmd_line);
  // cmd_line에 주어진 이름을 가진 실행 파일을 실행하고,
  // 전달된 인자들을 넘겨준 뒤,
  // 새 프로세스의 pid를 반환한다.
  // 어떤 이유로든 프로그램이 로드되거나 실행될 수 없는 경우,
  // 유효하지 않은 pid인 -1을 반환해야 한다.
  // 따라서 부모 프로세스는 자식 프로세스가 실행 파일을 성공적으로 
  // 로드했는지의 여부를 알 때까지, exec에서 리턴 불가능하며,
  // 이를 보장하기 위해 적절한 동기화를 사용해야 한다.
  
  // 커널 페이지 할당
  char *fn_copy = palloc_get_page(0);
  if(fn_copy == NULL)
    return TID_ERROR;

  strlcpy(fn_copy, cmd_line, PGSIZE);

  tid_t tid = process_execute(fn_copy);

  palloc_free_page(fn_copy);
  return tid;
}

int 
sys_wait(tid_t tid){
  /*
  자식 프로세스 pid를 기다리며 자식의 종료 상태(exit status)를 가져옴.
  만약 pid가 여전히 살아있다면, 종료될 때까지 기다린다.
  그런 다음 pid가 exit에 전달했던 상태값을 반환.
  만약 pin가 exit()을 호출하지 않고 커널에 의해 종료된 경우 
  wait(pid)는 반드시 -1을 반환해야 함.
  부모 프로세스가 wait을 호출할 시점에 이미 종료된 자식 프로세스를 기다리는 것도 적법하지만,
  커널은 부모가 자식의 종료 상태를 가져오거나 자식이 커널에 의해 종료되었음을 알 수 있도록 여전히 허용해야함.

  *다음 조건 중 하나라도 참이면 wait()은 실패하고 즉시 -1을 반환해야 함*
  - pid가 호출하는 직계 자식을 가리키지 않는 경우.
    pid가 호출하는 프로세스의 직계 자식인 경우는 오직 호출하는 프로세스가 exec의 성공적인 호출 결과로
    pid를 리턴 받았을 때뿐이다.
    (다음은 간소화된 pintos의 규칙이다.)
    자식은 상속되지 않는다는 점에 유의. 즉, A가 자식 B를 생성하고 B가 자식 프로세스 C를 생성한 경우,
    B가 죽었더라도 A는 C를 기다릴 수 없다.(원래는 부모의 부모가 해당 자식을 입약하여 리핑된다.)
    프로세스 A가 wait(C)를 호출하면 반드시 실패해야 함.
    마찬가지로, 고아(orphaned) 프로세스는 부모 프로세스가 먼저 종료되더라도 새로운 부모에게 할당되지 않음. 
  - wait()을 호출하는 프로세스가 이미 해당 pid에 대해 wait()을 호출한 적이 있는 경우.
    즉 프로세스는 주어진 자식에 대해 최대 한 번만 기다릴 수 있다.

  프로세스는 임의의 수의 자식을 생성할 수 있고, 어느 순서로든 기다릴 수 있으며, 
  일부 또는 모든 자식을 기다리지 않고 종료할 수도 있다.
  설계할 때 wait()이 발생할 수 있는 모든 방식을 고려해야 한다.
  
  부모가 자식을 한 번이라도 기다리든 말든, 그리고 자식이 부모보다 먼저 종료되든 나중에 종료되든 상관없이
  struct thread를 포함한 모든 자원은 반드시 해제되어야 한다. 
  
  초기프로세스가 종료될 때까지 Pintos가 종료되지 않도록 보장해야 한다. 
  제공된 pintos 코드는 threads/init.c의 main()에서 
  userprog/process.c의 process_wait()을 호출하여 이를 수행하려고 시도한다.
  함수 상단의 주석에 따라 process_wait()을 구현한 다음, 
  process_wait()을 활용해 wait system call을 구현할 것을 권장함.

  */
  // 현재 프로세스의 자식 중 해당 tid가 실제로 존재하는 지 확인 
  //struct thread *child = get_thread(tid);
  //if(child == NULL) return -1;

  // process_wait 호출하여 자식이 끝날 때까지 대기하고 exit status 받아오기
  int exit_status = process_wait(tid);

  return exit_status;
}

bool 
sys_create(const char *file, unsigned initial_size){
  check_str(file);
  lock_acquire(&filesys_lock);
  bool ok = filesys_create(file, initial_size);
  lock_release(&filesys_lock);
  return ok;
}

bool 
sys_remove(const char *file){
  check_str(file);
  lock_acquire(&filesys_lock);
  bool ok = filesys_remove(file);
  lock_release(&filesys_lock);
  return ok;
}

int 
sys_open(const char *file){
  check_str(file);
  lock_acquire(&filesys_lock);
  struct file *f = filesys_open(file);
  if(f==NULL){
    lock_release(&filesys_lock);
    return -1;
  }
  int fd = alloc_fd(f);
  if(fd==-1)
    file_close(f);
  lock_release(&filesys_lock);
  return fd;
}

int 
sys_filesize(int fd){
  struct file *f = fd_to_file(fd);
  if(f==NULL)
    return -1;
  lock_acquire(&filesys_lock);
  int len = file_length(f);
  lock_release(&filesys_lock);
  return len;
}

int 
sys_read(int fd, void *buffer, unsigned size){
  check_buffer(buffer, size);
  if(fd == 0){
    uint8_t *buf_ptr = buffer;
    unsigned i;
    for(i=0; i <size; i++){
      buf_ptr[i] = input_getc(); // 한 글자씩 읽어서 버퍼에 저장
    }
    return (int)size;
  }

  if(fd==1){
    return -1;
  }

  else if(fd < 0 || fd >= FD_MAX){
    return -1;
  }
  // 일반 파일인 경우,
  struct thread *curr = thread_current();
  struct file *file = curr ->fd_table[fd];
  if(file == NULL) return -1;
  
  lock_acquire(&filesys_lock);
  off_t bytes_read = file_read(file, buffer, size);
  lock_release(&filesys_lock);

  return (int)bytes_read;
}

int 
sys_write(int fd, const void *buffer, unsigned size){
  /* 
  열려 있는 fd에 buffer로부터 size 바이트만큼을 쓴다.
  실제로 쓰여진 바이트 수를 반환하며 일부 바이트를 쓸 수 없는 경우 size보다 작을 수 있다.
  (파일을 동적으로 늘리는 기능이 pintos에는 없기 떄문(원래 OS에는 있음))
  파일의 끝(EOF)를 넘어 쓰기를 시도하면 원래는 파일이 확장되어야 하지만,
  기본 파일 시스템에는 파일 크기 확장 기능이 구현되어 있지 않다.
  
  따라서 파일 끝까지 가능한 한 많은 바이트를 쓰고 실제로 쓰여진 바이트 수를 반환하거나,
  바이트를 전혀 쓸 수 없는 경우 0을 반환하는 것이 예상되는 메커니즘이다.

  fd 1은 콘솔에 출력한다. 콘솔에 쓰는 코드는, 적어도 수백 바이트를 넘지 않는 한,
  putbuf()의 호출로 buffer의 모든 내용을 작성해야 한다.
  (더 큰 버퍼를 나누어 쓰는 것은 허용된다.)
   // 멀티스레딩(동시성) 환경에서의 Race Condition/Interleaving을 막기 위해서 
  그렇지 않으면 서로 다른 프로세스가 출력하는 텍스트 줄들이 콘솔에 뒤섞여(interleaved)
  사람인 독자와 채점 스크립트 모두를 혼란스럽게 만들 수 있다. 

  void putbuf(const char *buffer, size_t size); // size_t는 unsigned int이다.
  // 커널 내부에서 버퍼에 들어 있는 문자열 데이터를 화면에 통째로 출력해주는 함수.(lib/kernel/console.h)
  */
  check_buffer(buffer, size);
  if(fd==1){
    putbuf(buffer, size);
    return (int)size;
  }
  else if(fd<=0 || fd>=FD_MAX){
    return -1;
  }
  // prj1-2

  // 일반 파일 처리: 현재 스레드의 fd_table에서 파일 객체 가져오기
  struct thread *curr = thread_current();
  struct file *file = curr->fd_table[fd];
  // fd 테이블 내에서 현재 fd를 찾아보고, 
  // 없다면 -1 리턴, 
  // 있다면 file_write() 호출 및 쓰여진 바이트 수 반환
  if(file == NULL) return -1;

  lock_acquire(&filesys_lock);
  off_t bytes_written = file_write(file, buffer, size);
  lock_release(&filesys_lock);

  return (int)bytes_written;
}

void 
sys_seek(int fd, unsigned position){
  struct file* f = fd_to_file(fd);
  if(f==NULL)
    return;
  lock_acquire(&filesys_lock);
  file_seek(f, position);
  lock_release(&filesys_lock);
  return;
}

unsigned 
sys_tell(int fd){
  struct file *f = fd_to_file(fd);
  if(f==NULL)
    return 0;
  lock_acquire(&filesys_lock);
  unsigned pos = file_tell(f);
  lock_release(&filesys_lock);
  return pos;
  return 0;
}

void 
sys_close(int fd){
  struct file *f = fd_to_file(fd);
  if(f==NULL)
    return;
  lock_acquire(&filesys_lock);
  file_close(f);
  lock_release(&filesys_lock);
  thread_current() -> fd_table[fd] = NULL;
}

int
sys_fibonacci (int n)
{
  if (n <= 0)
    return 0;
  int a = 0, b = 1;
  for (int i = 1; i < n; i++)
    {
      int t = a + b;
      a = b;
      b = t;
    }
  return b;
}

int
sys_max_of_four_int (int a, int b, int c, int d)
{
  int m = a;
  if (b > m) m = b;
  if (c > m) m = c;
  if (d > m) m = d;
  return m;
}

/* $int 0x30을 불렀을 때 호출되는 syscall_handler이다. */
static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //printf ("system call!\n");
  /* 현재 스택의 상태는 다음과 같다. */
  /*                     ex. write(fd, buffer, size);
    esp+16 |  arg3  |     
    esp+12 |  arg2  |        esp+12 |  size  |
    esp+8  |  arg1  |        esp+8  | buffer |
    esp+4  |  arg0  |        esp+4  |   fd   |
    esp -> | number |        esp -> | number |
  */

  // 현재 스택에 쌓여있는 값 중 esp에 저장된 syscall num을 가져온다. 
  check_addr(f->esp);
  //int syscall_num = *(int*)f->esp;
  int num = (int)get_arg(f,0);

  // 유효한 시스템 콜 번호인지 확인
  if(num<0 || num>14)
    sys_exit(-1);

  // 시스템 콜 번호에 따라 분기
  switch(num){
    case SYS_HALT: {
    // void halt (void) NO_RETURN;
      sys_halt();
      break;
    }
    case SYS_EXIT: {
      // void exit(int status)
      check_addr(f->esp+4);
      int exit_status = *(int*)((char *)f->esp +4);
      sys_exit(exit_status);
      break;
    }
    case SYS_EXEC: { 
      // pid_t exec (const char *file);
      check_addr(f->esp+4);
      const char* file_name = *(const char**)((char *)f->esp+4);
      if(file_name==NULL) sys_exit(-1);
      check_addr(file_name);
      f->eax = sys_exec(file_name);
      break;
    }
    case SYS_WAIT: {
      // int wait (pid_t);
      check_addr(f->esp+4);
      tid_t tid = *(tid_t *)((char *)f->esp+4);
      f->eax = sys_wait(tid);
      break;
    }
    case SYS_CREATE: {
      f->eax = sys_create((const char *)get_arg(f,1),
                          (unsigned)get_arg(f,2));
      break;
    }
    case SYS_REMOVE:{
      f->eax = sys_remove ((const char *) get_arg (f, 1));
      break;
    }
    case SYS_OPEN: {
      f->eax = sys_open ((const char *) get_arg (f, 1));
      break;
    }
    case SYS_FILESIZE: {
      f->eax = sys_filesize ((int) get_arg (f, 1));
      break;
    }
    case SYS_READ: {
      // int read (int fd, void *buffer, unsigned length);
      check_addr(f->esp+4);
      check_addr(f->esp+8);
      check_addr(f->esp+12);

      int fd = *(int*)((char *)f->esp+4);
      // f->esp+4의 공간을 주소값을 가리키는 포인터(const void **)로 간주
      // 여기에 들어가는 주소값을 가져오기(*)
      void * buffer = *(void **)((char *)f->esp+8);
      unsigned size = *(unsigned*)(f->esp+12);

      int ret = sys_read(fd, buffer, size);
      f-> eax = ret;
      break;
    }
    case SYS_WRITE: {
      // int write (int fd, const void *buffer, unsigned length);
      check_addr(f->esp+4);
      check_addr(f->esp+8);
      check_addr(f->esp+12);

      int fd = *(int*)((char *)f->esp+4);
      // (f->esp+8)에는 문자열의 주소값이 담기고 이 주소를 const void*로 읽는다.
      // 해당 값을 스택에서 꺼내오고 (*)
      // write 두 번째 인자인 buffer의 형으로 casting(const void*)
      void* buffer = *(void **)((char *)f->esp+8);
      unsigned size = *(unsigned*)(f->esp+12);

      int ret = sys_write(fd, buffer, size);
      f-> eax = ret;
      break;
    }
    case SYS_SEEK:{
      sys_seek ((int) get_arg (f, 1), (unsigned) get_arg (f, 2));
      break;
    }
    case SYS_TELL: {
      f->eax = sys_tell ((int) get_arg (f, 1));
      break;
    }
    case SYS_CLOSE:{
      sys_close ((int) get_arg (f, 1));
      break;
    }
    case SYS_FIBONACCI: {
      f->eax = sys_fibonacci ((int) get_arg (f, 1));
      break;
    }
    case SYS_MAX_OF_FOUR_INT: {
      f->eax = sys_max_of_four_int ((int) get_arg (f, 1), (int) get_arg (f, 2),
                                    (int) get_arg (f, 3), (int) get_arg (f, 4));
      break;
    }
    default:
      sys_exit (-1);            /* 알 수 없는 시스템 콜 번호 */
  }
  //thread_exit ();
}